<?php $__env->startSection('content'); ?>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="/Admin/Courses/<?php echo e($RoundId); ?>">My Courses</a></li>
          <li class="breadcrumb-item active" aria-current="page"><a href="/Admin/Course/<?php echo e($RoundId); ?>/Students">Students</a></li>
          <li class="breadcrumb-item active" aria-current="page">Students Details </li>
        </ol>
      </nav>
      <div class="ms-panel">
        <div class="ms-panel-body">
            <h2><?php echo e($Student->FullnameEn); ?></h2>
            <h4><?php echo e($CourseS->CourseNameEn); ?> - GR<?php echo e($Course->GroupNo); ?></h4>
            <div class="row">

                <div class="col-md-6">



                  <div class="">
                    <div class="ms-panel-header">
                      <h6>Attendence</h6>
                    </div>
                    <div class="ms-panel-body">
                      <div class="table-responsive">
                        <table id="StudentTable" class="dattable table table-striped thead-dark  w-100">
                          <thead>
                            <th>#</th>
                            <th>Session No</th>

                            <th>Attendence</th>
                          </thead>
                          <tbody>
                            <?php
                                $i = 1
                            ?>
                          <?php $__currentLoopData = $Attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($i); ?></td>
                              <td>Session <?php echo e($Session->SessionNumber); ?></td>


                              <td>
                                <?php if($Session->IsAttend == 1): ?>
                                    <i class="fas fa-check    "></i>
                                <span> Attended </span>
                                <?php elseif($Session->IsAttend === 0): ?>
                                    <i class="fas fa-times    "></i>
                                <span> Absent </span>
                                <?php else: ?>
                                Not set
                                <?php endif; ?>

                              </td>
                            </tr>
                            <?php
                                $i++
                            ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>


                </div>
                <div class="col-md-6">
                        <div class="">
                                <div class="ms-panel-header">
                                  <h6>Attendence KPI</h6>
                                </div>
                                <div class="ms-panel-body">
                                    <div class="row no-gutters">
                                            <div>


                                              <ul>
                                                <li><i class="fas fa-circle    "></i>  Total sessions = <?php echo e($Count); ?> </li>
                                                <li><i class="fas fa-circle    "></i> Total sessions run = <?php echo e($IsAttend); ?> </li>
                                                <li><i class="fas fa-circle    "></i> Total sessions absent = <?php echo e($NotAttend); ?> </li>
                                              </ul>


                                            </div>
                                            <div class="w-100 d-flex justify-content-center">
                                                    <div class="progress-rounded progress-round-tiny">
                                                      <div class="progress-value">
                                                        <?php if($Count !== 0): ?>
                                                            <?php echo e(number_format(($IsAttend/$Count)*100,0)); ?>

                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                        %</div>
                                                        <svg>
                                                          <circle class="progress-cicle bg-success"
                                                          cx="65"
                                                          cy="65"
                                                          r="57"
                                                          stroke-width="4"
                                                          fill="none"
                                                          aria-valuenow="
                                                          <?php if($Count !== 0): ?>
                                                          <?php echo e(number_format(($IsAttend/$Count)*100,0)); ?>

                                                          <?php else: ?>
                                                              0
                                                          <?php endif; ?>
                                                          "
                                                          aria-orientation="vertical"
                                                          aria-valuemin="0"
                                                          aria-valuemax="100"
                                                          role="slider">
                                                        </circle>
                                                      </svg>
                                                    </div>
                                                  </div>
                                    </div>
                                </div>
                              </div>
                </div>
              </div>
        </div>
      </div>
      <div class="row">

       <div class="col-md-12">
          <div class="ms-panel">
              <div class="ms-panel-header">
                <h6>ُQuiz and Exams</h6>
              </div>
              <div class="ms-panel-body">
                  <div class="row">
                      <div class="col-md-6">
                          <div class="d-flex justify-content-end">
                              <input type="reset" value="undo" class="btn btn-warning mb-2 mx-1 mt-0">

                              <input type="submit" value="Save" id="save" class="btn btn-success mb-2 mt-0">
                          </div>
                          <div class="table-responsive">
                              <table class="dattable table table-striped thead-dark  w-100" id="grades">
                                <thead>
                                  <th>#</th>
                                  <th>Session No</th>
                                  <th>Quiz Grade<br>100%</th>
                                  <th>Task Grade<br>100%</th>
                                  <th>Download Task</th>


                                </thead>
                                <tbody>
                                  <?php
                                      $i = 1
                                  ?>
                                    <?php $__currentLoopData = $Grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                                       <form action="">
                                                       <td><?php echo e($i); ?></td>
                                                         <td>
                                                           <span data-toggle="tooltip" data-placement="top" title="14/10/2019">

                                                             Session <?php echo e($Grade->SessionNumber); ?>

                                                           </span>
                                                         </td>

                                                         <td>

                                                         <input type="text" value="<?php echo e($Grade->QuizGrade); ?>" name="quiz1-grade" data-id="<?php echo e($Grade->TaskId); ?>" placeholder="10%" class="quiz form-control">
                                                         </td>
                                                         <td>
                                                         <input type="text" value="<?php echo e($Grade->TaskGrade); ?>" name="task1-grade" data-status="update" data-grade="<?php echo e($Grade->GradeId); ?>" placeholder="10%" class="task form-control">
                                                         </td>
                                                         <td>
                                                         <a href="<?php echo e(asset("/storage/$Grade->TaskURL")); ?>" Download class="ms-btn-icon-outline btn-info">
                                                                 <i class="fa fa-download"></i>
                                                               </a>
                                                         </td>

                                                       </form>
                                                     </tr>
                                                     <?php
                                                         $i++
                                                     ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                              </table>
                            </div>

                      </div>
                      <div class="col-md-6">
                          <div class="d-flex justify-content-end">
                              <input type="reset" value="undo" class="btn btn-warning mb-2 mx-1 mt-0">
                              <input type="submit" value="Save" id="saveExam" class="btn btn-success mb-2 mt-0">
                          </div>
                          <div class="table-responsive">
                              <table class="dattable table table-striped thead-dark  w-100" id="Exams">
                                <thead>
                                  <th>#</th>
                                  <th>Exam Name</th>
                                  <th>Exam Grade<br>100% </th>
                                  <th>Evaluation </th>


                                </thead>
                                <tbody>
                                  <?php
                                      $i = 1
                                  ?>
            <?php $__currentLoopData = $ExamGrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ExamGrade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                                    <form action="">
                                    <td><?php echo e($i); ?></td>
                                      <td>
                                      <span data-toggle="tooltip" data-placement="top" title="14/10/2019">

                                          <?php echo e($ExamGrade->ExamNameEn); ?>

                                        </span>
                                      </td>
                                      <td>
                                        <input type="hidden" class="gradeid" value="<?php echo e($ExamGrade->ExamGradesId); ?>">
                                      <input type="text" data-exam="<?php echo e($ExamGrade->ExamGradesId); ?>" value="<?php echo e($ExamGrade->Grade); ?>" name="quiz1-grade"  placeholder="10%" class="form-control grade-value">
                                      </td>
                                      <td>
                                        <ul class='stars'>
                                          <li class="star
                                          <?php if($ExamGrade->Evaluation == 1 || $ExamGrade->Evaluation == 2 || $ExamGrade->Evaluation == 3 ||$ExamGrade->Evaluation == 4 ||$ExamGrade->Evaluation == 5): ?>
                                              selected
                                          <?php endif; ?>
                                          <?php if($ExamGrade->Evaluation == 1 ): ?>
                                              value
                                          <?php endif; ?>
                                           " title='Poor' data-value='1'>
                                            <i class='fa fa-star fa-fw'></i>
                                          </li>
                                          <li class='star
                                          <?php if($ExamGrade->Evaluation == 2 || $ExamGrade->Evaluation == 3 ||$ExamGrade->Evaluation == 4 ||$ExamGrade->Evaluation == 5): ?>
                                              selected
                                          <?php endif; ?>
                                          <?php if($ExamGrade->Evaluation == 2 ): ?>
                                              value
                                          <?php endif; ?>
                                          ' title='Fair' data-value='2'>
                                            <i class='fa fa-star fa-fw'></i>
                                          </li>
                                          <li class='star
                                          <?php if($ExamGrade->Evaluation == 3 ||$ExamGrade->Evaluation == 4 ||$ExamGrade->Evaluation == 5): ?>
                                              selected
                                          <?php endif; ?>
                                          <?php if($ExamGrade->Evaluation == 3 ): ?>
                                              value
                                          <?php endif; ?>
                                          ' title='Good' data-value='3'>
                                            <i class='fa fa-star fa-fw'></i>
                                          </li>
                                          <li class='star
                                          <?php if($ExamGrade->Evaluation == 4 ||$ExamGrade->Evaluation == 5): ?>
                                              selected
                                          <?php endif; ?>
                                          <?php if($ExamGrade->Evaluation == 4 ): ?>
                                              value
                                          <?php endif; ?>
                                          ' title='Excellent' data-value='4'>
                                            <i class='fa fa-star fa-fw'></i>
                                          </li>
                                          <li class='star
                                          <?php if($ExamGrade->Evaluation == 5): ?>
                                              selected
                                          <?php endif; ?>
                                          <?php if($ExamGrade->Evaluation == 5 ): ?>
                                              value
                                          <?php endif; ?>
                                          ' title='WOW!!!' data-value='5'>
                                            <i class='fa fa-star fa-fw'></i>
                                          </li>
                                        </ul>
                                      </td>



                                    </form>

                                  </tr>
                                  <?php
                                      $i++
                                  ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                              </table>

                            </div>
                      </div>
                    </div>
              </div>

            </div>
       </div>
      </div>
      <div class="row">
          <div class="col-md-12">
            <div class="ms-panel">
                <div class="ms-panel-header d-flex py-2 align-items-center justify-content-between">
                    <h6>Tracks evaluations</h6>
                    <div>
                        <input type="reset" value="undo" class="btn btn-warning  mx-1 mt-0">

                        <input type="submit" id="saveStudentEval" class="btn btn-success" value="save">
                    </div>
                  </div>

              <div class="ms-panel-body">
                <div class="table-responsive">
                  <table id="studenteval" class="dattable table table-striped thead-dark  w-100">
                    <thead>
                      <th>#</th>
                      <th>Track</th>
                      <th>Time Respect<br>10%</th>
                      <th>Lecture Practice<br>10%</th>
                      <th>Solve Home Tasks<br>10%</th>
                      <th>Student Interaction<br>10%</th>
                      <th>Student Attitude<br>10%</th>
                      <th>Student Focus<br>10%</th>
                      <th>Understand Speed<br>10%</th>
                      <th>Extra Marks<br>10%</th>
                      <th>Overall<br>10%</th>
                      <th>Total</th>
                      <th>Notes</th>
                    </thead>
                    <tbody>
                      <?php
                          $i = 1
                      ?>
                      <?php $__currentLoopData = $StudentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($i); ?></td>
                            <td>
                                <span data-toggle="tooltip" data-placement="top" title="14/10/2019">

                                  <?php echo e($Evaluation->ContentNameEn); ?>

                                </span>
                              </td>
                              <td><input type="text" value="<?php echo e($Evaluation->TimeRespect); ?>" data-eval="<?php echo e($Evaluation->StudentEvaluationId); ?>" class="TimeRespect form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Lecture_Practice); ?>" class="LecturePractise form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Solve_Home_Tasks); ?>" class="SolveHomeTasks form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Student_Interaction); ?>" class="StudentInteractions form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Student_Attitude); ?>" class="StudentAttitude form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Student_Focus); ?>" class="StudentFocus form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Understand_Speed); ?>" class="UnderstandSpeed form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Exam_Marks); ?>" class="ExtraMarks form-control" placeholder="Eval/100"></td>
                              <td><input type="text" value="<?php echo e($Evaluation->Overall); ?>" class="Overall form-control" placeholder="100%"></td>
                              <?php $total = (($Evaluation->TimeRespect + $Evaluation->Lecture_Practice + $Evaluation->Solve_Home_Tasks + $Evaluation->Student_Interaction + $Evaluation->Student_Attitude + $Evaluation->Student_Focus + $Evaluation->Understand_Speed + $Evaluation->Exam_Marks + $Evaluation->Overall)/900)*100?>
                              <td>
                                  <div
                                  class="progress-circle"
                              data-value="0.<?php echo e(number_format($total,0)); ?>"
                                  data-size="50"
                                  data-thickness="3"
                                  data-animation-start-value="1.0"
                                  data-fill="{
                                    &quot;color&quot;: &quot;green&quot;
                                  }"
                                  data-reverse="true">
                                  <div class="percent">
                                  <?php echo e(number_format($total,0)); ?>%
                                  </div>
                                </div>
                              </td>
                              <td>
                              <textarea name=""  placeholder="note" cols="3" class="form-control notes"><?php echo e($Evaluation->Notes); ?></textarea>
                              </td>

                      </tr>
                      <?php
                          $i++
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      


                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
  </main>
    <!-- note Modal -->
    <div class="modal fade" id="NoteModal" tabindex="-1" role="dialog" aria-labelledby="NoteModal">
        <div class="modal-dialog modal-dialog-centered " role="document">
          <div class="modal-content">

            <div class="modal-body">

              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div class="ms-auth-container row no-gutters">
                  <div class="col-12 p-5">
                      <form action="">

                      <label for="note">Note</label>
                      <div class="input-group">
                         <textarea class="form-control" rows="5" placeholder="Write your note"></textarea>
                      </div>
                      <div class="input-group text-center">
                          <input type="submit" value="Add" class="btn btn-primary m-auto">
                      </div>
                      </form>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
  <!-- Task Modal -->
  <div class="modal fade" id="DoneTopics" tabindex="-1" role="dialog" aria-labelledby="DoneTopics">
    <div class="modal-dialog modal-dialog-centered " role="document">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
              aria-hidden="true">&times;</span></button>
          <div class="ms-auth-container row no-gutters">
            <div class="col-12 p-5">
              <form action="">
                <div class="row">
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="" checked="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span>   HTML </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="" checked="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> CSS </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="" checked="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> CSS3 </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> JavaScript </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>
                  <div class="col-md-6 my-2">
                    <label class="ms-checkbox-wrap ms-checkbox-success">
                      <input type="checkbox" value="">
                      <i class="ms-checkbox-check"></i>
                    </label>
                    <span> Jquery </span>
                  </div>

                </div>
                <div class="input-group text-center">
                  <input type="submit" value="Save" class="btn btn-success m-auto">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>