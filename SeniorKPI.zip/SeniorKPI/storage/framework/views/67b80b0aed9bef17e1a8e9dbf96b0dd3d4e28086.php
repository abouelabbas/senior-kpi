<?php $__env->startSection('content'); ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/Student"><i class="material-icons">home</i> Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Attendence & Evaluations</li>
            </ol>
          </nav>
        <div class="row">

            <div class="col-md-12">
             
    
    
              <div class="ms-panel">
                <div class="ms-panel-header">
                  <h6>Attendence</h6>
                </div>
                <div class="ms-panel-body">
                 <div class="row">
                   <div class="col-md-8">
                      <div class="table-responsive">
                          <table id="StudentTable" class="dattable table table-striped thead-dark  w-100">
                            <thead>
                              <th>#</th>
                              <th>Session No</th>
                              
                              <th>Attendence</th>
                              <th>Note</th>
                            </thead>
                            <tbody>
                              <?php
                                  $i = 1
                              ?>
                            <?php $__currentLoopData = $Attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Attend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($i); ?></td>
                                <td>
                                  <span data-toggle="tooltip" data-placement="top"  title="<?php echo e($Attend->SessionDate); ?>">

                                    Session <?php echo e($Attend->SessionNumber); ?>

                                  </span>
                                </td>
                               
                              
                                <td>
                                  <?php if($Attend->IsAttend == 1): ?>
                                  <i class="fas fa-check    "></i>
                                  <?php elseif($Attend->IsAttend !== 0): ?>
                                  <i class="fas fa-minus    "></i>
                                  <?php else: ?>
                                  <i class="fas fa-times    "></i>
                                  <?php endif; ?>
                                  
                                </td>
                                <td>
                                  <p><?php echo e($Attend->Notes); ?></p>
                                </td>
                              </tr>
                              <?php
                                  $i++
                              ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            
                             
                            </tbody>
                          </table>  
                        </div>
                   </div>
                   <div class="col-md-4 py-5 border">
                      
                    <ul>
                      <li><i class="fas fa-circle    "></i>  Total sessions = <?php echo e($AllAttend); ?> </li>
                      <li><i class="fas fa-circle    "></i> Total sessions run = <?php echo e($IsAttend); ?> </li>
                      <li><i class="fas fa-circle    "></i> Total sessions absent = <?php echo e($AllAttend - $IsAttend); ?> </li>
                    </ul>
                    <div class="progress-rounded progress-round-tiny ">
                          <div class="progress-value">
                              <?php if($AllAttend != 0): ?>
                              <?php echo e(number_format(($IsAttend/$AllAttend)*100,1)); ?>%
                              <?php else: ?>
                              0
                              <?php endif; ?>
                            </div>
                            <svg>
                              <circle class="progress-cicle bg-success"
                              cx="65"
                              cy="65"
                              r="57"
                              stroke-width="4"
                              fill="none"
                              aria-valuenow="
                              <?php if($AllAttend != 0): ?>
                              <?php echo e(($IsAttend/$AllAttend)*100); ?>

                              <?php else: ?>
                              0
                              <?php endif; ?>
                              "
                              aria-orientation="vertical"
                              aria-valuemin="0"
                              aria-valuemax="100"
                              role="slider">
                            </circle>
                          </svg>
                        </div>
                        <h3 class="text-center">total absence kpi</h3>
                   </div>
                 </div>
                </div>
              </div>
              
            
            </div>
    
          </div>
      <div class="row">

        <div class="col-md-12">
         

          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>ُMy Evaluation</h6>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="ms-panel-body">
                  <div class="table-responsive">
                    <table  class="dattable table table-striped thead-dark  w-100">
                      <thead>
                        <th>#</th>
                        <th>Session No</th>
                        <th>Quiz Grade</th>
                        <th>Task Grade</th>
                       
                      </thead>
                      <tbody>
                        <?php
                            $i = 1
                        ?>
                      <?php $__currentLoopData = $Grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($i); ?></td>
                          <td>
                            <span data-toggle="tooltip" data-placement="top"  title="<?php echo e($Grade->SessionDate); ?>">

                              Session <?php echo e($Grade->SessionNumber); ?>

                            </span>
                          </td>
                         
                          <td>
                            <?php echo e($Grade->QuizGrade); ?>/100
                          </td>
                          <td>
                            <?php echo e($Grade->TaskGrade); ?>/100
                          </td>
                          
                        </tr>
                        <?php
                            $i++
                        ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>  
                  </div>
                </div>
                
              </div>
              <div class="col-md-6">
                  <div class="ms-panel-body">
                      <div class="table-responsive">
                          <table  class="dattable table table-striped thead-dark  w-100">
                              <thead>
                                <th>#</th>
                                <th>Exam Name</th>
                                <th>Exam Grade </th>
                                <th>Evaluation </th>
                               
                              </thead>
                              <tbody>
                                <?php
                                    $i = 1
                                ?>
                              <?php $__currentLoopData = $ExamGrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                  <td>
                                    <span data-toggle="tooltip" data-placement="top"  title="14/10/2019">
  
                                      <?php echo e($Exam->ExamNameEn); ?>

                                    </span>
                                  </td>
                                  <td>
                                    <?php echo e($Exam->Grade); ?>/100
                                  </td>
                                  
                                  <td>
                                    <?php if($Exam->Evaluation == 1): ?>
                                    
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                        
                                    <?php elseif($Exam->Evaluation == 2): ?>
                                    
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <?php elseif($Exam->Evaluation == 3): ?>
                                    
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <?php elseif($Exam->Evaluation == 4): ?>
                                    
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <?php elseif($Exam->Evaluation == 5): ?>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <?php endif; ?>
                                     </td>
                                  
                                    </tr>
                                    <?php
                                        $i++
                                    ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                              </tbody>
                            </table>  

                      </div>  
                  </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="ms-panel">
                <div class="ms-panel-header">
                  <h6>KPIS</h6>
                </div>
                <div class="ms-panel-body">
                      <div class="table-responsive">
                          <table  class="dattable table table-striped thead-dark  w-100">
                              <thead>
                                <th>#</th>
                                <th>Track name</th>
                                <th>Attendence<br>5% </th>
                                <th>Time Respect<br>5% </th>
                                <th>Lecture Practice<br>5% </th>
                                <th>Assigned Tasks<br>10% </th>
                                <th>Inteaction<br>5% </th>
                                <th>Attiude<br>5%</th>
                                <th>Focus<br>5%</th>
                                <th>Understand Speed<br>5%</th>
                                <th>Exams<br>5%</th>
                                <th>total</th>
                                <th>note</th>
                              </thead>
                              <tbody>
                                <?php
                                    $i = 1
                                ?>
                                  <?php $__currentLoopData = $StudentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($i); ?></td>
                                  <td>
                                    <span data-toggle="tooltip" data-placement="top"  title="14/10/2019">
  
                                      <?php echo e($Evaluation->ContentNameEn); ?>

                                    </span>
                                  </td>
                                  <td><?php echo e($Evaluation->TimeRespect); ?>%</td>
                                  <td><?php echo e($Evaluation->Lecture_Practice); ?>%</td>
                                  <td><?php echo e($Evaluation->Solve_Home_Tasks); ?>%</td>
                                  <td><?php echo e($Evaluation->Student_Interaction); ?>%</td>
                                  <td><?php echo e($Evaluation->Student_Attitude); ?>%</td>
                                  <td><?php echo e($Evaluation->Student_Focus); ?>%</td>
                                  <td><?php echo e($Evaluation->Understand_Speed); ?>%</td>
                                  <td><?php echo e($Evaluation->Exam_Marks); ?>%</td>
                                  <td><?php echo e($Evaluation->Overall); ?>%</td>
                                  <?php $total = (($Evaluation->TimeRespect + $Evaluation->Lecture_Practice + $Evaluation->Solve_Home_Tasks + $Evaluation->Student_Interaction + $Evaluation->Student_Attitude + $Evaluation->Student_Focus + $Evaluation->Understand_Speed + $Evaluation->Exam_Marks + $Evaluation->Overall)/900)*100?>
                                  <td>
                                    <div
                                    class="progress-circle"
                                    data-value="0.<?php echo e(number_format($total,0)); ?>"
                                    data-size="50"
                                    data-thickness="3"
                                    data-animation-start-value="1.0"
                                    data-fill="{
                                      &quot;color&quot;: &quot;green&quot;
                                    }"
                                    data-reverse="true">
                                    <div class="percent">
                                        <?php echo e(number_format($total,0)); ?>%
                                    </div>
                                  </div>
                                  </td>
                                  <td class="note">
                                      <?php echo e($Evaluation->Notes); ?>

                                  </td>
                                </tr>
                                <?php
                                    $i++
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                              </tbody>
                            </table>  
                      </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts/studentkpi',['StudentRounds'=>$StudentRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>