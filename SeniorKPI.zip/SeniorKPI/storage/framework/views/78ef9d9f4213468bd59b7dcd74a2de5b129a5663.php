<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-info">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
                    <li class="breadcrumb-item"><a href="/Admin/Rounds"> Rounds</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> Attendence</li>
                </ol>
            </nav>
      <div class="row">

        <div class="col-md-12">

            <div class="ms-panel">
                <div class="ms-panel-header">
                <h2><?php echo e($Course->CourseNameEn); ?> - GR<?php echo e($Round->GroupNo); ?></h2>
                    <h6>Sessions List </h6>
                  
                </div>
                <div class="ms-panel-body">
                        <div class="d-flex w-100  justify-content-end">
                            <a href="#" class="btn btn-success m-0 mb-2"  data-toggle="modal" data-target="#addSession"> <i class="fas fa-plus"></i> Add new session</a> &nbsp; &nbsp;
                            <a href="/Admin/Rounds/<?php echo e($Round->RoundId); ?>/StopRound" class="btn btn-danger m-0 mb-2" > <i class="fas fa-times" style="color:#fff;"></i> Stop round</a>
                              </div>
                  <div class="table-responsive">
                    <table class=" fixed-thead-width dattable table thead-dark  w-100">
                      <thead>
                          <th>#</th>
                        <th>Session No </th>
                        <th>Date </th>
                        <th> note</th>
                        <th> Attendence</th>
                      </thead>
                      <tbody>
                          <?php
                              $i = 1
                          ?>
                       <?php $__currentLoopData = $Sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                       <tr class="
                       <?php if(\Carbon\Carbon::today()->format('Y-m-d') < $Session->SessionDate): ?>
                       alert alert-success 
                       <?php else: ?>
                       alert alert-dark
                       <?php endif; ?>
                       ">
                       <td><?php echo e($i); ?></td>
                        <td><?php echo e($Session->SessionNumber); ?></td>
                        
                        <td><?php echo e($Session->SessionDate); ?></td>
                       <td><?php echo e($Session->Notes); ?></td>
                           
                          <td>
                          <a href="/Admin/Rounds/Session/<?php echo e($Session->SessionId); ?>/Attendance" class="btn-outline-info btn"> <i class="fas fa-eye mr-1"></i>View</a>
                          </td>
                           
                         
                      </tr>
                      <?php
                          $i++
                      ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>  
                  </div>
                </div>
              </div>
        
        </div>

      </div>
      <div class="modal fade" id="addSession" tabindex="-1" role="dialog" aria-labelledby="addCourse">
            <div class="modal-dialog modal-lg modal-dialog-centered modal " role="document">
              <div class="modal-content">
        
                <div class="modal-body">
        
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <div class="ms-auth-container row no-gutters">
                      <div class="col-12 p-3">
                          <form action="/Admin/Rounds/Sessions/Add" method="POST">
                            <?php echo e(csrf_field()); ?>

                              <div class="ms-auth-container row">
                              <input type="hidden" value="<?php echo e($RoundId); ?>" name="RoundId">
    
                                  
                                  <div class="col-md-6">
                                      <div class="form-group">
                                          <label for="note">Session Number</label>
                                          <div class="input-group">
                                              <input type="text" name="SessionNumber" id="round_Number" class="form-control"
                                                 placeholder="Session Number">
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-6">
                                      <div class="form-group">
                                          <label for="note">Session Date</label>
                                          <div class="input-group">
                                              <input type="date" name="SessionDate" id="round_ST_Date" data-toggle="datepicker" class="form-control"
                                                 placeholder="Round Start Date">
                                          </div>
                                      </div>
                                  </div>
                                  
                                  <!-- <div class="col-md-6">
                                      <div class="form-group">
                                          <label for="note">Assigned Course</label>
                                          <div class="input-group">
                                              <select name="" id="round_course_Assigned" class="form-control">
                                                  <option value="fullstack">FullStack</option>
                                                  <option value="meanstack">MeanStack</option>
                                              </select>
                                          </div>
                                      </div>
                                  </div> -->
                                  
                                  <!--  Add Round days and times -->
                                  
                                  <!--  /Add Round days and times -->

                                  
                                  
                                  
                                  <div class="col-md-12">
                                      <div class="form-group">
                                          <label for="note">Note</label>
                                          <div class="input-group">
                                              <textarea name="Notes" id="note" class="form-control"  
                                                  rows="5" placeholder="Note"></textarea>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="input-group d-flex justify-content-end text-center">
                                <input type="button" value="Cancel" class="btn btn-dark mx-2" data-dismiss="modal" aria-label="Close">                       
                                <input type="Submit" value="Add" class="btn btn-success ">                       
                            </div>
                          </form>
                      </div>
                    </div>
                  </div>
        
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>