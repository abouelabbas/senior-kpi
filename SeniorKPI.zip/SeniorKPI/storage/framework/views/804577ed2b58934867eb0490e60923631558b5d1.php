<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><i class="material-icons">home</i> Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Attendence & Evaluations</li>
    </ol>
  </nav>

<div class="row">

<div class="col-md-12">
 


    <div class="ms-panel">
        <div class="ms-panel-header d-flex justify-content-between">
          <h6>Course Evaluation Per Track</h6>
        </div>
        <div class="ms-panel-body">
          <div class="table-responsive">
                <table id="courseEval" class="dattable table table-striped thead-dark  w-100">
                        <thead>
                          <th>#</th>
                          <th>Topic</th>
                          <th>Knowledge Experience</th>
                          <th>Topics Qualified</th>
                          <th>Topics Preperation</th>
                          <th>Trainer Attiude</th>
                          <th>Time Respect </th>
                          <th>Students Interaction</th>
                          <th>Overall Evaluation</th>
                          <th>Total</th>
                          
                        </thead>
                        <tbody>
                          <?php
                              $i = 1
                          ?>
      <?php if($TrainerEvalCount != 0): ?>
      <?php $__currentLoopData = $TrainerEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TrainerEval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($i); ?></td>
      <td><?php echo e($TrainerEval->ContentNameEn); ?></td>
  
      <td>
          <?php if(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) == 1): ?>
          
          <i class="fa fa-star" aria-hidden="true"></i>
              
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) < 2): ?>
          
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fas fa-star-half"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) == 2): ?>
          
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) < 3): ?>
          
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fas fa-star-half"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) == 3): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) < 4): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fas fa-star-half"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) == 4): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) < 5): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fas fa-star-half"></i>
          <?php elseif(($TrainerEval->Knowledge_Experience/$TrainerEval->EvalCount) == 5): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <i class="fa fa-star" aria-hidden="true"></i>
          <?php endif; ?>
           </td>
           <td>
              <?php if(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) == 1): ?>
              
              <i class="fa fa-star" aria-hidden="true"></i>
                  
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) < 2): ?>
              
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fas fa-star-half"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) == 2): ?>
              
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) < 3): ?>
              
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fas fa-star-half"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) == 3): ?>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) < 4): ?>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fas fa-star-half"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) == 4): ?>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) < 5): ?>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fas fa-star-half"></i>
              <?php elseif(($TrainerEval->Training_Qualified/$TrainerEval->EvalCount) == 5): ?>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <?php endif; ?>
               </td>
               <td>
                  <?php if(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) == 1): ?>
                  
                  <i class="fa fa-star" aria-hidden="true"></i>
                      
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) < 2): ?>
                  
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) == 2): ?>
                  
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) < 3): ?>
                  
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) == 3): ?>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) < 4): ?>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) == 4): ?>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) < 5): ?>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fas fa-star-half"></i>
                  <?php elseif(($TrainerEval->Topics_Preparation/$TrainerEval->EvalCount) == 5): ?>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <?php endif; ?>
                   </td>
                   <td>
                      <?php if(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) == 1): ?>
                      
                      <i class="fa fa-star" aria-hidden="true"></i>
                          
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) < 2): ?>
                      
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fas fa-star-half"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) == 2): ?>
                      
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) < 3): ?>
                      
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fas fa-star-half"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) == 3): ?>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) < 4): ?>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fas fa-star-half"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) == 4): ?>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) < 5): ?>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fas fa-star-half"></i>
                      <?php elseif(($TrainerEval->Trainer_Attitude/$TrainerEval->EvalCount) == 5): ?>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <i class="fa fa-star" aria-hidden="true"></i>
                      <?php endif; ?>
                       </td>
                       <td>
                          <?php if(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) == 1): ?>
                          
                          <i class="fa fa-star" aria-hidden="true"></i>
                              
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Time_Respect/$TrainerEval->EvalCount) < 2): ?>
                          
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fas fa-star-half"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) == 2): ?>
                          
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Time_Respect/$TrainerEval->EvalCount) < 3): ?>
                          
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fas fa-star-half"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) == 3): ?>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Time_Respect/$TrainerEval->EvalCount) < 4): ?>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fas fa-star-half"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) == 4): ?>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Time_Respect/$TrainerEval->EvalCount) < 5): ?>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fas fa-star-half"></i>
                          <?php elseif(($TrainerEval->Time_Respect/$TrainerEval->EvalCount) == 5): ?>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <i class="fa fa-star" aria-hidden="true"></i>
                          <?php endif; ?>
                           </td>
                           <td>
                              <?php if(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) == 1): ?>
                              
                              <i class="fa fa-star" aria-hidden="true"></i>
                                  
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) < 2): ?>
                              
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fas fa-star-half"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) == 2): ?>
                              
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) < 3): ?>
                              
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fas fa-star-half"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) == 3): ?>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) < 4): ?>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fas fa-star-half"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) == 4): ?>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) < 5): ?>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fas fa-star-half"></i>
                              <?php elseif(($TrainerEval->Student_Interaction/$TrainerEval->EvalCount) == 5): ?>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <i class="fa fa-star" aria-hidden="true"></i>
                              <?php endif; ?>
                               </td>

                               <td>
                                  <?php if(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) == 1): ?>
                                  
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                      
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) > 1 && ($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) < 2): ?>
                                  
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fas fa-star-half"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) == 2): ?>
                                  
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) > 2 && ($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) < 3): ?>
                                  
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fas fa-star-half"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) == 3): ?>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) > 3 && ($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) < 4): ?>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fas fa-star-half"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) == 4): ?>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) > 4 && ($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) < 5): ?>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fas fa-star-half"></i>
                                  <?php elseif(($TrainerEval->Overall_Evaluation/$TrainerEval->EvalCount) == 5): ?>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <i class="fa fa-star" aria-hidden="true"></i>
                                  <?php endif; ?>
                                   </td>
                         
                          
                          <td>
                            <?php 
                              $total1 = ((($TrainerEval->Knowledge_Experience + $TrainerEval->Training_Qualified + $TrainerEval->Topics_Preparation + $TrainerEval->Trainer_Attitude + $TrainerEval->Time_Respect + $TrainerEval->Student_Interaction + $TrainerEval->Overall_Evaluation)/$TrainerEval->EvalCount)/35)*100;
                              ?>
                              <div
                              class="progress-circle"
                              data-value="0.<?php echo e(number_format($total1,0)); ?>"
                              data-size="50"
                              data-thickness="3"
                              data-animation-start-value="1.0"
                              data-fill="{
                                &quot;color&quot;: &quot;green&quot;
                              }"
                              data-reverse="true">
                              <div class="percent">
                                  <?php echo e(number_format($total1,0)); ?>%
                              </div>
                            </div>
                          </td>
                          
                      </tr>
                      <?php
                          $i++
                      ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
                          
      
                        </tbody>
                      </table>
          </div>
        </div>
      </div>
    
      
  

</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts/trainerkpi',['TrainerRounds'=>$TrainerRounds,'HistoryRounds'=>$HistoryRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>