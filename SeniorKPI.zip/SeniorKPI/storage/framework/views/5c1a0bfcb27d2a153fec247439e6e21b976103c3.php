<?php $__env->startSection('content'); ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="/Admin/Courses/<?php echo e($Round->RoundId); ?>"><?php echo e($Course->CourseNameEn); ?> - <?php echo e($Round->GroupNo); ?></a></li>
              <li class="breadcrumb-item active" aria-current="page">Sessions</li>
            </ol>
          </nav>
      <div class="row">

        <div class="col-md-12">

          <div class="ms-panel">
            <div class="ms-panel-header">
                <h2><?php echo e($Course->CourseNameEn); ?> - <?php echo e($Round->GroupNo); ?> </h2>
                <h6>Sessions List </h6>
            </div>
            <div class="ms-panel-body">
              <div class="table-responsive">
                <table id="stdListTable"  class="dattable table table-striped thead-dark  w-100">
                  <thead>
                    <th>#</th>
                    <th class="text-left">Session </th>
                    <th class="text-left"> Material</th>
                    <th class="text-left">Videos </th>
                    <th class="text-left">Quiz</th>
                    <th class="text-left">Task</th>
                    
                  </thead>
                  <tbody>
                    <?php
                        $i = 1
                    ?>
                      <?php $__currentLoopData = $Sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                          <td><?php echo e($i); ?></td>
                          <td>
                              <span data-toggle="tooltip" data-placement="top" title="14/10/2019">
    
                                Session <?php echo e($Session->SessionNumber); ?>

                              </span>
                            </td>
                        <td>
                        <a href="#" class="btn btn-square btn-outline-success has-icon" data-toggle="modal" data-target="#MaterialModal<?php echo e($Session->SessionId); ?>" >
                          <?php if($Session->SessionMaterial !== null || $Session->MaterialText !== null): ?>
                              <i class="fa fa-check"></i> 
                          <?php else: ?>
                              <i class="fa fa-upload"></i> 
                          <?php endif; ?>
                            Upload
                          </a>
                        </td>
                        <td> 
                        <a href="#" class="btn btn-square btn-outline-info has-icon" data-toggle="modal" data-target="#VideoModal<?php echo e($Session->SessionId); ?>" >
                          <?php if($Session->SessionVideo !== null || $Session->VideoText !== null): ?>
                          <i class="fa fa-check"></i> 
                      <?php else: ?>
                          <i class="fa fa-upload"></i> 
                      <?php endif; ?> Upload
                          </a>
                        </td>
                        <td>
                        <a href="#" class="btn btn-square btn-outline-dark has-icon" data-toggle="modal" data-target="#QuizModal<?php echo e($Session->SessionId); ?>" >
                            <?php if($Session->SessionQuiz !== null || $Session->QuizText !== null): ?>
                              <i class="fa fa-check"></i> 
                          <?php else: ?>
                              <i class="fa fa-upload"></i> 
                          <?php endif; ?> Upload
                          </a>
                        </td>
                        <td>
                        <a href="#" class="btn btn-square btn-outline-primary has-icon" data-toggle="modal" data-target="#TaskModal<?php echo e($Session->SessionId); ?>" >
                            <?php if($Session->SessionTask !== null || $Session->TaskText !== null): ?>
                              <i class="fa fa-check"></i> 
                          <?php else: ?>
                              <i class="fa fa-upload"></i> 
                          <?php endif; ?> Upload
                          </a>
                        </td>
                      </tr>
                      <?php
                          $i++
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>  
              </div>
            </div>
          </div>
        
        </div>

      </div>
    </div>

  </main>

  <?php $__currentLoopData = $Sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SessionModal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Material Modal -->
<div class="modal fade" id="MaterialModal<?php echo e($SessionModal->SessionId); ?>" tabindex="-1" role="dialog" aria-labelledby="MaterialModal">
      <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
  
          <div class="modal-body">
              <form action="/Admin/Session/ContentUpload" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="SessionId" class="form-control" value="<?php echo e($SessionModal->SessionId); ?>" />
                <input type="hidden" name="SessionRole" class="form-control" value="Material" />
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div class="ms-auth-container row no-gutters">
                  <div class="col-12 p-5">
                        
                        <div class="input-group mb-3">
                            <div class="custom-file">
                      <input type="file" name="MaterialFile" value="<?php echo e($SessionModal->SessionMaterial); ?>" id="inputGroupFile0<?php echo e($SessionModal->SessionId); ?> student_img" class="custom-file-input">
                      
                                <label class="custom-file-label" for="inputGroupFile0<?php echo e($SessionModal->SessionId); ?>">Choose file</label>
                            </div>
                        </div>
                      <label for="note">Note</label>
                      <div class="input-group">
                          <textarea name="MaterialText" id="note" class="form-control" rows="10" placeholder="write note"></textarea>
                         
                      </div>
                      <div class="input-group text-center">
                          <input type="submit" value="upload" class="btn btn-success m-auto">                       
                      </div>
                  </div>
                </div>
              </form>
            </div>
  
          </div>
        </div>
      </div>
      <!-- Material Modal -->
    <div class="modal fade" id="VideoModal<?php echo e($SessionModal->SessionId); ?>" tabindex="-1" role="dialog" aria-labelledby="MaterialModal">
        <div class="modal-dialog modal-dialog-centered " role="document">
          <div class="modal-content">
    
            <div class="modal-body">
                <form action="/Admin/Session/ContentUpload" method="POST" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="SessionId" class="form-control" value="<?php echo e($SessionModal->SessionId); ?>" />
                    <input type="hidden" name="SessionRole" class="form-control" value="Video" />
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <div class="ms-auth-container row no-gutters">
                      <div class="col-12 p-5">
                            
                          <label for="note">Session URL</label>
                          <div class="input-group">
                              <textarea name="VideoText" id="note" class="form-control" rows="10" placeholder="write note"></textarea>
                             
                          </div>
                          <div class="input-group text-center">
                              <input type="submit" value="upload" class="btn btn-success m-auto">                       
                          </div>
                      </div>
                    </div>
                </form>
              </div>
    
            </div>
          </div>
        </div>
        <!-- Material Modal -->
      <div class="modal fade" id="QuizModal<?php echo e($SessionModal->SessionId); ?>" tabindex="-1" role="dialog" aria-labelledby="MaterialModal">
        <div class="modal-dialog modal-dialog-centered " role="document">
          <div class="modal-content">
    
            <div class="modal-body">
                <form action="/Admin/Session/ContentUpload" method="POST" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="SessionId" class="form-control" value="<?php echo e($SessionModal->SessionId); ?>" />
                    <input type="hidden" name="SessionRole" class="form-control" value="Quiz" />
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <div class="ms-auth-container row no-gutters">
                      <div class="col-12 p-5">
                            
                            <div class="input-group mb-3">
                                <div class="custom-file">
                          <input type="file" name="QuizFile" value="<?php echo e($SessionModal->SessionQuiz); ?>" id="inputGroupFileq0<?php echo e($SessionModal->SessionId); ?> student_img" class="custom-file-input">
                          
                                    <label class="custom-file-label" for="inputGroupFileq0<?php echo e($SessionModal->SessionId); ?>">Choose file</label>
                                </div>
                            </div>
                            <label for="note">Note</label>
                          <div class="input-group">
                              <textarea name="QuizText" id="note" class="form-control" rows="10" placeholder="write note"></textarea>
                             
                          </div>
                          <div class="input-group text-center">
                              <input type="submit" value="upload" class="btn btn-success m-auto">                       
                          </div>
                      </div>
                    </div>
                </form>
              </div>
    
            </div>
          </div>
        </div>
        <!-- Material Modal -->
      <div class="modal fade" id="TaskModal<?php echo e($SessionModal->SessionId); ?>" tabindex="-1" role="dialog" aria-labelledby="MaterialModal">
        <div class="modal-dialog modal-dialog-centered " role="document">
          <div class="modal-content">
    
            <div class="modal-body">
                <form action="/Admin/Session/ContentUpload" method="POST" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="SessionId" class="form-control" value="<?php echo e($SessionModal->SessionId); ?>" />
                    <input type="hidden" name="SessionRole" class="form-control" value="Task" />
    
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <div class="ms-auth-container row no-gutters">
                      <div class="col-12 p-5">
                            
                            <div class="input-group mb-3">
                                <div class="custom-file">
                          <input type="file" name="TaskFile" value="<?php echo e($SessionModal->SessionMaterial); ?>" id="inputGroupFilet0<?php echo e($SessionModal->SessionId); ?> student_img" class="custom-file-input">
                          
                                    <label class="custom-file-label" for="inputGroupFilet0<?php echo e($SessionModal->SessionId); ?>">Choose file</label>
                                </div>
                            </div>
                          <label for="note">Note</label>
                          <div class="input-group">
                              <textarea name="TaskText" id="note" class="form-control" rows="10" placeholder="write note"></textarea>
                             
                          </div>
                          <div class="input-group text-center">
                              <input type="submit" value="upload" class="btn btn-success m-auto">                       
                          </div>
                      </div>
                    </div>
                </form>
              </div>
    
            </div>
          </div>
        </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>