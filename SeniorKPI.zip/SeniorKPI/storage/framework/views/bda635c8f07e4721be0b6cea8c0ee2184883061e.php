<?php $__env->startSection('content'); ?>
    

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
                    <li class="breadcrumb-item"><a href="/Admin/Courses"> Courses</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($Course->CourseNameEn); ?></li>
                </ol>
            </nav>
            <div class="row">

                <div class="col-md-12">

                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6><?php echo e($Course->CourseNameEn); ?> </h6>
                        </div>
                        <div class="ms-panel-body">
                                <form action="">
                                        <div class="ms-auth-container row">
        
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course EN Name</label>
                                                    <div class="input-group">
                                                        <input type="text" id="course_EN_Name" class="form-control"
                                                            value="<?php echo e($Course->CourseNameEn); ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course AR Name</label>
                                                    <div class="input-group">
                                                        <input type="text" id="course_AR_Name" class="form-control"
                                                            value="<?php echo e($Course->CourseNameAr); ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course EN Description</label>
                                                    <div class="input-group">
                                                        <textarea name="" id="course_EN_DESC" class="form-control" readonly
                                                            rows="5"><?php echo e($Course->DescriptionEn); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course AR Description</label>
                                                    <div class="input-group">
                                                        <textarea name="" id="course_AR_DESC" class="form-control" readonly
                                                    rows="5"><?php echo e($Course->DescriptionAr); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course Hours</label>
                                                    <div class="input-group">
                                                        <input type="text" id="course_hourse" class="form-control" value="<?php echo e($Course->Duration); ?>"
                                                            readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Course Cost</label>
                                                    <div class="input-group">
                                                        <input type="text" id="course_cost" class="form-control" value="<?php echo e($Course->CourseCost); ?>"
                                                            readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="note">Status</label>
                                                    <div>
                                                        <label class="ms-switch">
                                                            <input type="checkbox" disabled 
                                                            <?php if($Course->Active == 1): ?>
                                                                checked="checked"
                                                            <?php else: ?>
                                                                
                                                            <?php endif; ?>
                                                            >
                                                            <span class="ms-switch-slider ms-switch-info round"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="note">Note</label>
                                                    <div class="input-group">
                                                        <textarea name="" id="note" class="form-control" readonly
                                                            rows="5"><?php echo e($Course->Notes); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                        </div>
                    </div>
                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>MeanStack </h6>
                        </div>
                        <div class="ms-panel-body">
                            <div class="row no-gutters">
                                <div class="col-md-4 col-sm-8">
                                    <ul class="nav nav-tabs d-flex nav-justified mb-4" role="tablist">
                                        <li role="presentation"><a href="#Roundes" aria-controls="Roundes" class="active show" role="tab" data-toggle="tab" aria-selected="true">Roundes</a></li>
                                        <li role="presentation"><a href="#Trainers" aria-controls="Trainers" role="tab" data-toggle="tab" class="" aria-selected="false">Trainers </a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active show" id="Roundes">
                                                <div class="table-responsive">
                                                        <table  class="dattable table table-striped thead-dark  w-100">
                                                          <thead>
                                                                <th># </th>
                                                                <th>Round </th>
                                                            <th>Start Date </th>
                                                            <th>Trainer </th>
                                                            <th>Branch </th>
                                                            <th>Lab </th>
                                                          </thead>
                                                          <tbody>
                                                              <?php $i = 1; ?>
                                                          <?php $__currentLoopData = $Rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <tr>
                                                              <td><?php echo e($i); ?></td>
                                                              <td>
                                                                <span>
                                        
                                                                  <?php echo e($Round->CourseNameEn); ?> GR <?php echo e($Round->GroupNo); ?>

                                                                </span>
                                                              </td>
                                                              <td> <?php echo e($Round->StartDate); ?> </td>
                                                              <td> <?php echo e($Round->FullnameEn); ?> </td>
                                                              <td> <?php echo e($Round->BranchNameEn); ?> </td>
                                                              <td> Lab <?php echo e($Round->LabNumber); ?> </td>
                                                             
                                                             
                                                              
                                                             
                                                            </tr>
                                                            <?php $i++; ?>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                          
                                                            
                                                           
                                                          
                                                           
                                                          </tbody>
                                                        </table>  
                                            </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Trainers">
                                        <div class="table-responsive">
                                                <table  class="dattable smal-tb table table-striped thead-dark  w-100">
                                                        <thead>
                                                                <th>#</th>
                                                                <th> </th>
                                                          <th>Trainer </th>
                                                          <th>Mobile </th>
                                                          <th> Social Links </th>
                                                          <th> </th>
                                                        </thead>
                                                        <tbody>
                                                            <?php $x = 1; ?>
                                                                <?php $__currentLoopData = $Trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($x); ?></td>
                                                                  <td  class="img"> 
                                                                <?php if($Trainer->ImagePath): ?>
                                                                <img style="width:30px;height:30px" class="img-circle profile" src="<?php echo e(asset("$Trainer->ImagePath")); ?>">                                                                    
                                                                <?php else: ?>
                                                                <img style="width:30px;height:30px" class="img-circle profile" src="<?php echo e(asset('img/user.jpg')); ?>">
                                                                <?php endif; ?>      
                                                                </td>
                                                                <td>
                                                                
                                          <?php echo e($Trainer->FullnameEn); ?>

                                                                
                                                                </td>
                                                                <td> <?php echo e($Trainer->Phone); ?> </td>
                                                                <td> 
                                                                  <a href="#" class="ms-btn-icon btn-pill btn-secondary"> <i class="fab fa-facebook-f    "></i> </a>
                                                                  <a href="#" class="ms-btn-icon btn-pill btn-info"> <i class="fab fa-linkedin    "></i> </a>
                                                                  <a href="#" class="ms-btn-icon btn-pill btn-danger"> <i class="fab fa-youtube    "></i> </a>
                                                                </td>
                                                                <td>
                                                                        <a href="/Admin/Trainers/Profile/<?php echo e($Trainer->TrainerId); ?>" class="btn btn-success">
                                                                      View Profile
                                                                  </a>
                                                                  <a href="/Admin/Courses/<?php echo e($Course->CourseId); ?>/Topics/<?php echo e($Trainer->TrainerId); ?>" class="btn mx-1 btn-dark">
                                                                      Course Topics
                                                                  </a>
                                                                 
                                                                </td>
                                                               
                                                                
                                                               
                                                              </tr>
                                                              <?php $x++; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                              
                                                            
                                                              
                                                             
                                                            
                                                         
                                                        </tbody>
                                                      </table>  
                                              </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>