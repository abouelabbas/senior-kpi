<?php $__env->startSection('content'); ?>

                <div class="ms-profile-overview">
                    <div class="ms-profile-cover">
                        <img class="ms-profile-img" src="https://via.placeholder.com/270x270" alt="people">
                        <div class="ms-profile-user-info">
                        <h1 class="ms-profile-username"><?php echo e($Student->FullnameEn); ?></h1>
                            <h2 class="ms-profile-role"><?php echo e($Student->Job); ?></h2>
                        </div>
    
                    </div>
                    <div class="ms-profile-navigation nav nav-tabs tabs-bordered w-100 d-flex justify-content-end">
                        
                    <a href="/Admin/Students/Edit/<?php echo e($Student->StudentId); ?>" class="btn btn-primary m-2 has-icon"> <i class="flaticon-pencil"
                                aria-hidden="true"></i> Edit</a>
                    </div>
                </div>
    
                <div class="row">
    
    
                    <div class="col-xl-5 col-md-12">
                        <div class="ms-panel ms-panel-fh">
                            <div class="ms-panel-body">
    
                                <h2 class="section-title">Basic Information</h2>
                                <table class="table ms-profile-information">
                                    <tbody>
                                        <tr>
                                            <th scope="row">Full Name</th>
                                        <td><?php echo e($Student->FullnamaEn); ?></td>
                                        </tr>
    
                                        <tr>
                                            <th scope="row">Email Address</th>
                                            <td><?php echo e($Student->Email); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Birthday</th>
                                            <td><?php echo e($Student->Birthdate); ?></td>
                                        </tr>
    
                                        <tr>
                                            <th scope="row">Phone Number</th>
                                            <td><?php echo e($Student->Phone); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">First time of join</th>
                                            <td><?php echo e($Student->JoinDate); ?></td>
                                        </tr>
    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
    
                    <div class="col-xl-7 col-md-12">
                        <div class="ms-panel ms-panel-fh">
                            <div class="ms-panel-body">
    
                                <h2 class="section-title">Basic Information</h2>
                                <div class="table-scrollable">
                                    <table class="table ms-profile-information text-left">
                                        <tbody>
                                            
                                            <tr>
                                                <th scope="row">Job</th>
                                                <td><?php echo e($Student->Job); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Company</th>
                                                <td><?php echo e($Student->Company); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Social Links</th>
                                                <td>
                                                    
                                                    <?php if($Student->Facebook): ?>
                                                    <a href="<?php echo e($Student->Facebook); ?>" class="ms-btn-icon btn-pill btn-secondary"> <i class="fab fa-facebook-f    "></i> </a>
                                                      <?php endif; ?>
                                                      <?php if($Student->Youtube): ?>
                                                          <a href="<?php echo e($Student->Youtube); ?>" class="ms-btn-icon btn-pill btn-info"> <i class="fab fa-linkedin    "></i> </a>
                                                      <?php endif; ?>
                                                      <?php if($Student->Linkedin): ?>
                                                          <a href="<?php echo e($Student->Linkedin); ?>" class="ms-btn-icon btn-pill btn-danger"> <i class="fab fa-youtube    "></i> </a>
                                                      <?php endif; ?>
                                                </td>
                                            </tr>
    
                                           
    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
    
    
    
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="ms-panel ms-panel-fh">
                            <div class="ms-panel-body">
    
                                <h2 class="section-title">Rounds</h2>
                                <div class="table-responsive">
                                    <table  class="dattable smal-tb table table-striped thead-dark  w-100">
                                        <thead>
                                            <th>#</th>
                                          <th>Round </th>
                                          
                                          
                                          <th> </th>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1;?>
                                        <?php $__currentLoopData = $Rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>
                                            
                      
                                               <?php echo e($Round->CourseNameEn); ?> GR <?php echo e($Round->GroupNo); ?>

                                            
                                            </td>
                                            
                                            <td>
                                            <a href="/Admin/Evaluations/<?php echo e($Round->RoundId); ?>" class="btn btn-dark" >
                                                    Evaluation
                                                </a>
                                                <a href="/Admin/Course/<?php echo e($Round->RoundId); ?>/Attendance" class="btn btn-warning" >
                                                    Attendence
                                                </a>
            
                                             
                                            </td>
                                           
                                            
                                           
                                          </tr>
                                          <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                        
                                          
                                         
                                        
                                         
                                        </tbody>
                                      </table>  
                                   
                                   
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>