<?php $__env->startSection('content'); ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">My Courses</li>
            </ol>
          </nav>
      <div class="row">

        <div class="col-md-12">

          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>Courses List </h6>
            </div>
            <div class="ms-panel-body">
              <div class="table-responsive">
                <table  class="dattable table table-striped thead-dark  w-100">
                  <thead>
                    <th>Course Name </th>
                    <th> </th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $TrainerRounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TrainerRound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($TrainerRound->RoundId == $RoundId): ?>
                        <tr>
                    <td>
                      <span data-toggle="tooltip" data-placement="top"  title="14/10/2019">

                        <?php echo e($TrainerRound->CourseNameEn); ?> G<?php echo e($TrainerRound->GroupNo); ?>

                      </span>
                    </td>
                    <td>
                    <a href="/Admin/Course/<?php echo e($TrainerRound->RoundId); ?>/Students" class="text-primary">
                        <i class="fas fa-users    "></i> Students
                      </a>
                    </td>
                    <td>
                    <a href="/Admin/Rounds/<?php echo e($TrainerRound->RoundId); ?>/Attendance" class="text-dark">
                        <i class="fas fa-table"></i> Attendence
                      </a>
                    </td>
                    <td>
                      <a href="/Admin/Course/<?php echo e($TrainerRound->RoundId); ?>/Sessions" class="text-success">
                       <i class="fas fa-laptop-code    "></i> Sessions
                      </a>
                    </td>
                    <td>
                      <a href="/Admin/Course/<?php echo e($TrainerRound->RoundId); ?>/DoneTopics" class="text-info">
                       <i class="fas fa-thumbs-up"></i> Done Topics
                      </a>
                    </td>
                   
                  </tr> 
                    <?php endif; ?>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $HistoryRounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HistoryRound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($HistoryRound->RoundId == $RoundId): ?>
                      <tr>
                  <td>
                    <span data-toggle="tooltip" data-placement="top"  title="14/10/2019">

                      <?php echo e($HistoryRound->CourseNameEn); ?> G<?php echo e($HistoryRound->GroupNo); ?>

                    </span>
                  </td>
                  <td>
                  <a href="/Admin/Course/<?php echo e($HistoryRound->RoundId); ?>/Students" class="text-primary">
                      <i class="fas fa-users    "></i> Students
                    </a>
                  </td>
                  <td>
                  <a href="/Admin/Course/<?php echo e($HistoryRound->RoundId); ?>/Attendance" class="text-dark">
                      <i class="fas fa-table"></i> Attendence
                    </a>
                  </td>
                  <td>
                  <a href="/Admin/Course/<?php echo e($HistoryRound->RoundId); ?>/Sessions" class="text-success">
                     <i class="fas fa-laptop-code    "></i> Sessions
                    </a>
                  </td>
                  <td>
                    <a href="/Admin/Course/<?php echo e($HistoryRound->RoundId); ?>/DoneTopics" class="text-info">
                     <i class="fas fa-thumbs-up    "></i> Done Topics
                    </a>
                  </td>
                 
                </tr> 
                  <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                   
                  </tbody>
                </table>  
              </div>
            </div>
          </div>
        
        </div>

      </div>
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>