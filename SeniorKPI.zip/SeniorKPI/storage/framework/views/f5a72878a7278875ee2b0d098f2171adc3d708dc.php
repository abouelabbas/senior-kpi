<?php $__env->startSection('content'); ?>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"><i class="material-icons">home</i> Home</a></li>
                    <li class="breadcrumb-item"><a href="labs.html"> Labs</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> Edit Lab</li>
                </ol>
            </nav>
            <div class="row">

                <div class="col-md-12">

                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>Edit Lab </h6>
                        </div>
                        <div class="ms-panel-body">
                                <form action="/Admin/Labs/Edit" method="POST">
                        <?php echo e(csrf_field()); ?>

                                        <div class="ms-auth-container row">
                      
                                            
                                        <input type="hidden" name="LabId" value="<?php echo e($Lab->LabId); ?>"/>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label  >Lab Number</label>
                                                    <div class="input-group">
                                                    <input type="text" name="LabNumber" value="<?php echo e($Lab->LabNumber); ?>" id="Lab_Number" class="form-control"
                                                           placeholder="Lab Number">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label  >Lab Capacity</label>
                                                    <div class="input-group">
                                                    <input type="text" name="LabCapacity" value="<?php echo e($Lab->LabCapacity); ?>" id="Lab_Capacity" class="form-control"
                                                           placeholder="Lab Capacity">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label  >Branch Name</label>
                                                    <div class="input-group">
                                                            <select name="BranchId" id="Branch_Name" class="form-control">
                                                                    <?php $__currentLoopData = $Branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option 
                                                                        
                                                                        <?php if($Branch->BranchId == $Lab->BranchId): ?>
                                                                            checked="checked"
                                                                        <?php endif; ?>
                                                                        
                                                                        value="<?php echo e($Branch->BranchId); ?>"><?php echo e($Branch->BranchNameEn); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group d-flex justify-content-end text-center">
                                            <a href="labs.html" class="btn btn-dark mx-2"> Cancel </a>                       
                                            <input type="submit" value="Save" class="btn btn-success ">                       
                                        </div>
                                    </form>
                        </div>
                    </div>
                   

                </div>

            </div>
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>