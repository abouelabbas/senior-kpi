<?php $__env->startSection('content'); ?>
<?php if(session('content')): ?>
<div class="alert alert-success">
    <?php echo e(session('content')); ?>

</div>
<?php endif; ?>
<?php if(session('delete')): ?>
<div class="alert alert-danger">
    <?php echo e(session('delete')); ?>

</div>
<?php endif; ?>
        <div class="row">

            <div class="col-md-12">

                <div class="ms-panel">
                    <div class="ms-panel-header">
                        <h5>Topics </h5>
                        <h6><?php echo e($Trainer->FullnameEn); ?> - <?php echo e($Course->CourseNameEn); ?> </h6>
                    </div>
                    <div class="ms-panel-body">
                        <!--  -->
                        <div class="d-flex justify-content-end">
                            <a href="#" class="btn btn-dark m-2 has-chevron" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="true">
                                Add
                            </a>

                            <ul class="dropdown-menu">
                                <li class="ms-dropdown-list">
                                    <a class="media p-2" href="#" data-toggle="modal" data-target="#addTrack">
                                        Track
                                    </a>
                                    <a class="media p-2" href="#" data-toggle="modal" data-target="#addTopic ">
                                        Topic
                                    </a>
                                    <a class="media p-2" href="#" data-toggle="modal" data-target="#addExample">
                                        Example
                                    </a>
                                    <a class="media p-2" href="#" data-toggle="modal" data-target="#addTask">
                                        Task
                                    </a>

                                </li>
                            </ul>
                            
                        </div>
                        <div class="accordion has-gap ms-accordion-chevron" id="accordionExample4">
                            <?php $__currentLoopData = $Agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card">
                                <div class="card-header" data-toggle="collapse" role="button" data-target="#topic<?php echo e($Ag->TrainerAgendaId); ?>"
                                    aria-expanded="false" aria-controls="collapseTen">
                                    <span class="has-icon">
                                        <i class="fas fa-code"></i> <?php echo e($Ag->ContentNameEn); ?>

                                    </span>
                                </div>

                                <div id="topic<?php echo e($Ag->TrainerAgendaId); ?>" class="collapse" data-parent="#accordionExample4">
                                    <div class="card-body">


                                        <div class="table-responsive">
                                            <table class="dattable table table-striped thead-warning  w-100">
                                                <thead>
                                                    <th>#</th>
                                                    <th>Point</th>
                                                    <th>Example </th>
                                                    <th>Task</th>
                                                    <th>Edit</th>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $SubAgenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubAg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($Ag->TrainerAgendaId == $SubAg->TrainerAgendaId): ?>
                                                        <tr>
                                                        <td><?php echo e($i); ?></td>
                                                                <td>
                                                                    
                                                                    <span><?php echo e($SubAg->SubAgendaNameEn); ?></span>
                                                                </td>
                                                                <td>
                                                                        
                                                                    <span>ex: <?php echo e($SubAg->Example); ?></span>
                                                                </td>
                                                                <td><span>ex: <?php echo e($SubAg->Task); ?></span> </td>
                                                            <td> <a href="#" data-toggle="modal" data-target="#editTopic<?php echo e($SubAg->TrainerSubAgendaId); ?>"
                                                                        class="ms-btn-icon btn-dark"><i
                                                                            class="fas fa-pencil-alt    "></i></a> </td>
                                                            </tr>
                                                            <?php $i++; ?>
                                                        <?php endif; ?>
                                                       
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    




                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        </div>

    </main>



    <!-- Track Modal -->
    <div class="modal fade" id="addTrack" tabindex="-1" role="dialog" aria-labelledby="addTopic">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-body">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <div class="ms-auth-container row no-gutters">
                        <div class="col-12 p-5">
                            <form action="/Admin/Courses/Topics/Track/Add" method="POST">
<?php echo e(csrf_field()); ?>

                                <label for="note">Track Name</label>
                                <div class="input-group">
                                        <input type="hidden" value="<?php echo e($TrainerId); ?>" name="id">
                                        <input type="hidden" value="<?php echo e($CourseId); ?>" name="cid">
                                    <input type="text" name="content" class="form-control" placeholder="track name">
                                </div>
                                <div class="input-group text-center">
                                    <input type="submit" value="Add" class="btn btn-success m-auto">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- topic Modal -->
    <div class="modal fade" id="addTopic" tabindex="-1" role="dialog" aria-labelledby="addTopic">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-body">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <div class="ms-auth-container row no-gutters">
                        <div class="col-12 p-5">
                            <form action="/Admin/Courses/Topics/Topic/Add" method="POST">
                                <?php echo e(csrf_field()); ?>

                                    <label>Track</label>
                                    <div class="input-group">
                                        <select name="TrainerAgendaId" id="" class="form-control">
                                            <?php $__currentLoopData = $Agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AgendaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($AgendaItem->TrainerAgendaId); ?>"> <?php echo e($AgendaItem->ContentNameEn); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <label for="note">Topic Name</label>
                                <div class="input-group">
                                        <input type="hidden" value="<?php echo e($TrainerId); ?>" name="id">
                                        <input type="hidden" value="<?php echo e($CourseId); ?>" name="cid">

                                    <input type="text" name="subcontent" class="form-control" placeholder="topic name">
                                </div>
                                <div class="input-group text-center">
                                    <input type="submit" value="Add" class="btn btn-success m-auto">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php $__currentLoopData = $SubAgenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MSubAg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- edit topic Modal -->
<div class="modal fade" id="editTopic<?php echo e($MSubAg->TrainerSubAgendaId); ?>" tabindex="-1" role="dialog" aria-labelledby="editTopic">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-body">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <div class="ms-auth-container row no-gutters">
                        <div class="col-12 p-5">
                            <div class="d-flex justify-content-end">
                            <a href="/Admin/Courses/Topic/Sub/<?php echo e($MSubAg->TrainerSubAgendaId); ?>/<?php echo e($CourseId); ?>/<?php echo e($TrainerId); ?>" class="btn btn-danger"> <i class="fas fa-trash"></i> </a>
                            </div>
                            <form action="/Admin/Courses/Topics/Edit" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($TrainerId); ?>" name="id">
                                <input type="hidden" value="<?php echo e($CourseId); ?>" name="cid">
                            <input type="hidden" name="TrainerSubAgendaId" value="<?php echo e($MSubAg->TrainerSubAgendaId); ?>" />
                                <label for="note">Topic Name</label>
                                <div class="input-group">
                                <input type="text" name="Topic" value="<?php echo e($MSubAg->SubAgendaNameEn); ?>" class="form-control" placeholder="topic name">
                                </div>
                                <label for="note">Example Name</label>
                                <div class="input-group">
                                <input type="text" name="Example" value="<?php echo e($MSubAg->Example); ?>" class="form-control" placeholder="example name">
                                </div>
                                <label for="note">Task Name</label>
                                <div class="input-group">
                                <input type="text" name="Task" value="<?php echo e($MSubAg->Task); ?>" class="form-control" placeholder="task name">
                                </div>
                                <div class="input-group text-center">
                                    <input type="submit" value="Save" class="btn btn-success m-auto">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <!-- example Modal -->
    <div class="modal fade" id="addExample" tabindex="-1" role="dialog" aria-labelledby="addExample">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-body">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <div class="ms-auth-container row no-gutters">
                        <div class="col-12 p-5">
                            <form action="/Admin/Courses/Topics/Example/Add" method="POST">
                                <?php echo e(csrf_field()); ?>

                                    <label>Track</label>
                                    <div class="input-group">
                                            <input type="hidden" value="<?php echo e($TrainerId); ?>" name="id">
                                            <input type="hidden" value="<?php echo e($CourseId); ?>" name="cid">
                                        <select name="TrainerAgendaId" id="agenda" class="form-control">
                                                <?php $__currentLoopData = $Agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AgendaItem2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($AgendaItem2->TrainerAgendaId); ?>"> <?php echo e($AgendaItem2->ContentNameEn); ?> </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <label for="note">Topic Name</label>
                                <div class="input-group">
                                    <select name="TrainerSubAgendaId" id="subagenda" class="form-control">
                                            
                                    </select>
                                </div>
                                <label for="note">Example Name</label>
                                <div class="input-group">
                                    <input type="text" name="Example" class="form-control" placeholder="Example name">
                                </div>
                                <div class="input-group text-center">
                                    <input type="submit" value="Add" class="btn btn-success m-auto">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Task Modal -->
    <div class="modal fade" id="addTask" tabindex="-1" role="dialog" aria-labelledby="addTask">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-body">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <div class="ms-auth-container row no-gutters">
                        <div class="col-12 p-5">
                                <form action="/Admin/Courses/Topics/Task/Add" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <label>Track</label>
                                        <div class="input-group">
                                                <input type="hidden" value="<?php echo e($TrainerId); ?>" name="id">
                                                <input type="hidden" value="<?php echo e($CourseId); ?>" name="cid">
                                            <select name="TrainerAgendaId" id="agenda2" class="form-control">
                                                    <?php $__currentLoopData = $Agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AgendaItem2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($AgendaItem2->TrainerAgendaId); ?>"> <?php echo e($AgendaItem2->ContentNameEn); ?> </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <label for="note">Topic Name</label>
                                    <div class="input-group">
                                        <select name="TrainerSubAgendaId" id="subagenda2" class="form-control">
                                                
                                        </select>
                                    </div>
                                    <label for="note">Task Name</label>
                                    <div class="input-group">
                                        <input type="text" name="Task" class="form-control" placeholder="Task name">
                                    </div>
                                    <div class="input-group text-center">
                                        <input type="submit" value="Add" class="btn btn-success m-auto">
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>