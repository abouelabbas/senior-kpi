<?php $__env->startSection('content'); ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/Admin"><i class="material-icons">home</i> Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="/Admin/Courses/<?php echo e($Round->RoundId); ?>"><?php echo e($Course->CourseNameEn); ?> - GR<?php echo e($Round->GroupNo); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Done Topics</li>
                </ol>
            </nav>
            <div class="row">

                <div class="col-md-12">

                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h2><?php echo e($Course->CourseNameEn); ?> - GR<?php echo e($Round->GroupNo); ?> </h2>
                            <h6>Topics </h6>
                        </div>
                        <div class="ms-panel-body">
                            <div class="accordion has-gap ms-accordion-chevron" id="accordionExample4">
                              <?php $__currentLoopData = $Topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="card">
                                    <div class="card-header" data-toggle="collapse" role="button"
                                  data-target="#HTML<?php echo e($Topic->RoundContentId); ?>" aria-expanded="false" aria-controls="collapseTen">
                                        <span class="has-icon"> 
                                            <i class="fas fa-code"></i> <?php echo e($Topic->ContentNameEn); ?> 
                                        </span>
                                    </div>

                                    <div id="HTML<?php echo e($Topic->RoundContentId); ?>" class="collapse" data-parent="#accordionExample4">
                                        <div class="card-body">
                                            <!--  -->
                                            <div class="d-flex justify-content-end">
                                                <a href="#" class="btn btn-dark m-2 has-chevron"data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" >
                                                     Add
                                                </a>
                                               
                                                  <ul class="dropdown-menu">
                                                    <li class="ms-dropdown-list">
                                                      <a class="media p-2" href="#" data-toggle="modal" data-target="#addTopic<?php echo e($Topic->RoundContentId); ?>">
                                                        Topic
                                                      </a>
                                                      <a class="media p-2" href="#" data-toggle="modal" data-target="#addExample<?php echo e($Topic->RoundContentId); ?>">
                                                        Example
                                                      </a>
                                                      <a class="media p-2" href="#" data-toggle="modal" data-target="#addTask<?php echo e($Topic->RoundContentId); ?>">
                                                        Task
                                                      </a>
                                                     
                                                    </li>
                                                  </ul>
                                                <input type="submit" class="btn btn-success my-2" value="Save">
                                            </div>

                                            <div class="table-responsive">
                                                    <table class="dattable table table-striped thead-warning  w-100">
                                                      <thead>
                                                        <th>#</th>
                                                        <th>Point</th>
                                                        <th>Example </th>
                                                        <th>Task</th>
                                                        <th>Edit</th>
                                                      </thead>
                                                      <tbody>
                                                        <?php
                                                            $i = 1
                                                        ?>
                                                        <?php $__currentLoopData = $SubTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubTopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($SubTopic->RoundContentId == $Topic->RoundContentId): ?>
                                                        <tr>
                                                        <td><?php echo e($i); ?></td>
                                                            <td>
                                                              <?php if($SubTopic->PointDone == 1): ?>
                                                              <i class="fas fa-check"></i>
                                                              <?php else: ?>
                                                              <i class="fas fa-spinner"></i>
                                                              <?php endif; ?>
                                                              <span><?php echo e($SubTopic->SubContentNameEn); ?></span>
                                                            </td>
                                                            <td>
                                                                <?php if($SubTopic->DoneExample == 1): ?>
                                                                <i class="fas fa-check"></i> 
                                                                <?php else: ?>
                                                                <i class="fas fa-spinner"></i>
                                                                <?php endif; ?>
                                                              <span><?php echo e($SubTopic->Example); ?></span>
                                                            </td>
                                                            <td>
                                                                <?php if($SubTopic->DoneTask == 1): ?>
                                                                <i class="fas fa-check"></i> 
                                                                <?php else: ?>
                                                                <i class="fas fa-spinner"></i>
                                                                <?php endif; ?>
                                                              <span><?php echo e($SubTopic->Task); ?></span>
                                                            </td>
                                                          <td> <a href="#" data-toggle="modal" data-target="#editTopic<?php echo e($SubTopic->RoundSubContentsId); ?>" class="ms-btn-icon btn-dark"><i class="fas fa-pencil-alt    "></i></a> </td>
   
                                                          </tr>
                                                          <?php
                                                              $i++
                                                          ?>
                                                        <?php endif; ?>
                                                           
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                      </tbody>
                                                    </table>
                                                  </div>
                                        </div>
                                    </div>
                                </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </main>

    
  
  <?php $__currentLoopData = $Topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Topicname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- topic Modal -->
  <div class="modal fade" id="addTopic<?php echo e($Topicname->RoundContentId); ?>" tabindex="-1" role="dialog" aria-labelledby="addTopic">
      <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
  
          <div class="modal-body">
  
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="ms-auth-container row no-gutters">
                <div class="col-12 p-5">
                    <form action="/Admin/DoneTopics/Add/<?php echo e($Topicname->RoundId); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                    <label for="note">Topic Name</label>
                    <div class="input-group">
                        <input type="text" name="TrainerSubAgendaName" class="form-control" placeholder="topic name">
                        <input type="hidden" name="RoundId" class="form-control" value="<?php echo e($Topicname->RoundId); ?>" placeholder="topic name">
                        <input type="hidden" name="RoundContentId" class="form-control" value="<?php echo e($Topicname->RoundContentId); ?>" placeholder="topic name">
                    </div>
                    <div class="input-group text-center">
                        <input type="submit" value="Add" class="btn btn-success m-auto">                       
                    </div>
                    </form>
                </div>
              </div>
            </div>
  
          </div>
        </div>
      </div>
      
<!-- example Modal -->
<div class="modal fade" id="addExample<?php echo e($Topicname->RoundContentId); ?>" tabindex="-1" role="dialog" aria-labelledby="addExample">
  <div class="modal-dialog modal-dialog-centered " role="document">
    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <div class="ms-auth-container row no-gutters">
            <div class="col-12 p-5">
                <form action="/Admin/DoneTopics/Example/<?php echo e($Topicname->RoundId); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                <label for="note">Topic Name</label>
                <div class="input-group">
                   <select name="SubContentId" id=""  class="form-control">
                     <?php $__currentLoopData = $SubTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($sub->RoundContentId == $Topicname->RoundContentId): ?>
                   <option value="<?php echo e($sub->RoundSubContentsId); ?>"><?php echo e($sub->SubContentNameEn); ?></option>
                   <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                </div>
                <label for="note">Example Name</label>
                <div class="input-group">
                   <input type="text" name="Example" class="form-control" placeholder="Example name">
                </div>
                <div class="input-group text-center">
                    <input type="submit" value="Add" class="btn btn-success m-auto">                       
                </div>
                </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

<!-- Task Modal -->
<div class="modal fade" id="addTask<?php echo e($Topicname->RoundContentId); ?>" tabindex="-1" role="dialog" aria-labelledby="addTask">
  <div class="modal-dialog modal-dialog-centered " role="document">
    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <div class="ms-auth-container row no-gutters">
            <div class="col-12 p-5">
                <form action="/Admin/DoneTopics/Task/<?php echo e($Topicname->RoundId); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                <label for="note">Topic Name</label>
                <div class="input-group">
                   <select name="SubContentId" id=""  class="form-control">
                      <?php $__currentLoopData = $SubTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($sub2->RoundContentId == $Topicname->RoundContentId): ?>
                    <option value="<?php echo e($sub2->RoundSubContentsId); ?>"><?php echo e($sub2->SubContentNameEn); ?></option>
                    <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                </div>
                <label for="note">task Name</label>
                <div class="input-group">
                   <input type="text" name="Task" class="form-control" placeholder="task name">
                </div>
                <div class="input-group text-center">
                    <input type="submit" value="Add" class="btn btn-success m-auto">                       
                </div>
                </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php $__currentLoopData = $Topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TopicContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $SubTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TopicSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <!-- edit topic Modal -->
<div class="modal fade" id="editTopic<?php echo e($TopicSub->RoundSubContentsId); ?>" tabindex="-1" role="dialog" aria-labelledby="editTopic">
      <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
  
          <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="ms-auth-container row no-gutters">
                <div class="col-12 p-5">
                    <div class="d-flex justify-content-end">
                        <a href="/Admin/Course/DoneTopics/Delete/<?php echo e($TopicSub->RoundSubContentsId); ?>/<?php echo e($TopicSub->RoundSubContentsId); ?>/<?php echo e($TopicContent->RoundId); ?>" class="btn btn-danger"> <i class="fas fa-trash"></i> </a>
                    </div>
                    <form action="/Admin/DoneTopics/Edit/<?php echo e($Topicname->RoundId); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      
                      <input type="hidden" name="RoundSubContentsId" value="<?php echo e($TopicSub->RoundSubContentsId); ?>" />
                      <input type="hidden" name="TrainerSubAgendaId" value="<?php echo e($TopicSub->RoundSubContentsId); ?>" />

                    <label for="note">Topic Name</label>
                    <div class="input-group">
                    <input type="text" name="SubAgendaName" value="<?php echo e($TopicSub->SubContentNameEn); ?>" class="form-control" placeholder="topic name">
                    </div>
                    <label for="note">Topic Done</label>
                    <div class="input-group">
                    <input type="checkbox" name="PointDone"
                    <?php if($TopicSub->PointDone == 1): ?>
                    checked 
                    <?php endif; ?>
                    class="form-control" placeholder="topic name">
                    </div>
                    <label for="note">Example Name</label>
                    <div class="input-group">
                    <input type="text" name="Example" class="form-control" value="<?php echo e($TopicSub->Example); ?>" placeholder="example name">
                    </div>
                    <label for="note">Example Done</label>
                    <div class="input-group">
                    <input type="checkbox" name="DoneExample"
                    <?php if($TopicSub->DoneExample == 1): ?>
                    checked 
                    <?php endif; ?>
                    class="form-control" placeholder="topic name">
                    </div>
                    <label for="note">Task Name</label>
                    <div class="input-group">
                    <input type="text" name="Task" class="form-control" value="<?php echo e($TopicSub->Task); ?>" placeholder="task name">
                    </div>
                    <label for="note">Task Done</label>
                    <div class="input-group">
                    <input type="checkbox" name="DoneTask"
                    <?php if($TopicSub->DoneTask == 1): ?>
                    checked 
                    <?php endif; ?>
                    class="form-control" placeholder="topic name">
                    </div>
                    <div class="input-group text-center">
                        <input type="submit" value="Save" class="btn btn-success m-auto">                       
                    </div>

                    </form>
                </div>
              </div>
            </div>
  
          </div>
        </div>
      </div>    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi',['ActiveRounds'=>$ActiveRounds], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>