<?php $__env->startSection('content'); ?>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"><i class="material-icons">home</i> Home</a></li>
                    <li class="breadcrumb-item"><a href="StudentsL.html"> Students</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> Edit Student</li>
                </ol>
            </nav>
            <div class="row">

                <div class="col-md-12">

                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>Trainer Info </h6>
                        </div>
                        <div class="ms-panel-body">
                                <form action="/Admin/Students/Edit" method="POST">
                        <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class=" form-group col-md-6">
                                            <label  >Student EN Name</label>
                                            <div class="input-group">
                                            <input type="hidden" name="StudentId" value="<?php echo e($Student->StudentId); ?>" />
                                               <input disabled type="text" value="<?php echo e($Student->FullnameEn); ?>" name="FullnameEn" class="form-control" id="student_EN_Name" placeholder="student EN name">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student AR Name</label>
                                            <div class="input-group">
                                               <input disabled type="text" value="<?php echo e($Student->FullnameAr); ?>" name="FullnameAr" class="form-control" id="student_AR_Name" placeholder="student AR name">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Password</label>
                                            <div class="input-group">
                                               <input disabled type="password" value="<?php echo e($Student->Password); ?>" name="Password" class="form-control" id="student_PR_mobile" placeholder="Student mobile">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                          <label  >Student Mobile</label>
                                          <div class="input-group">
                                             <input disabled type="text" name="Phone" value="<?php echo e($Student->Phone); ?>" class="form-control" id="student_PR_mobile" placeholder="Student mobile">
                                          </div>
                                      </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Whatsapp</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Whatsapp" value="<?php echo e($Student->Whatsapp); ?>" class="form-control" id="student_Whatsapp" placeholder="Student Whatsapp">
                                            </div>
                                        </div>
                                        
                                        <div class=" form-group col-md-6">
                                            <label  >Student FB Account</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Facebook" value="<?php echo e($Student->Facebook); ?>" class="form-control" id="student_FB_Account" placeholder="Student FB Account">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student DOB</label>
                                            <div class="input-group">
                                               <input disabled type="date" name="Birthdate" value="<?php echo e($Student->Birthdate); ?>" class="form-control" id="student_DOB" placeholder="Student DOB">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Adderss</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Address" value="<?php echo e($Student->Address); ?>" class="form-control" id="student_Adderss" placeholder="Student Adderss">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Education</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Education"  value="<?php echo e($Student->Education); ?>" class="form-control" id="student_Education" placeholder="Student Education">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student University</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="University"  value="<?php echo e($Student->University); ?>"  class="form-control" id="student_University" placeholder="Student University">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Faculty</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Faculty" value="<?php echo e($Student->Faculty); ?>"  class="form-control" id="student_Faculty" placeholder="Student Faculty">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label  >Student Nationality</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Nationality" value="<?php echo e($Student->Nationality); ?>"  class="form-control" id="student_Nationality" placeholder="Student Nationality">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label>Student Job</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Job" value="<?php echo e($Student->Job); ?>"  class="form-control" id="student_JOB" placeholder="Student JOB">
                                            </div>
                                        </div>
                                        <div class=" form-group col-md-6">
                                            <label>Student Company</label>
                                            <div class="input-group">
                                               <input disabled type="text" name="Company" value="<?php echo e($Student->Company); ?>"  class="form-control" id="student_Company" placeholder="Student Company">
                                            </div>
                                        </div>
                                        
                                        <div class=" form-group col-md-6">
                                            <label>Student Image</label>
                                            
                                            <div class="input-group">
                                                    <div class="input-group mb-3">
                                                            <div class="custom-file">
                                                      <input type="file" disabled name="ImagePath" value="<?php echo e($Student->ImagePath); ?>" id="inputGroupFile03 student_img" class="custom-file-input disabled">
                                                      
                                                                <label class="custom-file-label" for="inputGroupFile03">Choose file</label>
                                                            </div>
                                                        </div>
                                        </div>
                                        <div class=" form-group col-md-12">
                                            <label  >note</label>
                                            <div class="input-group">
                                               <textarea disabled id="trainer_note" name="AdditionalNotes" class="form-control" placeholder="Note" rows="4"><?php echo e($Student->AdditionalNotes); ?></textarea>
                                            </div>
                                        </div>
                                  </div>
                                        <div class="input-group d-flex justify-content-end text-center">
                                            <a href="/Admin/Students" class="btn btn-dark mx-2"> Cancel </a>                       
                                            <input type="submit" value="Save" class="btn btn-success ">                       
                                        </div>
                                      </form>
                        </div>
                    </div>
                    <div class="ms-panel">
                        
                            <div class="ms-panel-body">
                                    <div class="row no-gutters">
                                        <div class="col-md-2 col-sm-6">
                                            <ul class="nav nav-tabs d-flex nav-justified mb-4" role="tablist">
                                                <li role="presentation"><a href="#Roundes" aria-controls="Roundes" class="active show" role="tab" data-toggle="tab" aria-selected="true">Roundes</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane fade in active show" id="Roundes">
                                                   
                                            <div class="table-responsive">
                                                        <table  class="dattable table table-striped thead-dark  w-100">
                                                          <thead>
                                                              <th>#</th>
                                                            <th>Round </th>
                                                            <th>Start Date </th>
                                                            <th>Trainer </th>
                                                            <th>Branch </th>
                                                            <th>Lab </th>
                                                          </thead>
                                                          <tbody>
                                                              <?php
                                                                  $i = 1
                                                              ?>
                                                          <?php $__currentLoopData = $Rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <tr>
                                                              <td><?php echo e($i); ?></td>
                                                              <td>
                                                                <span>
                                        
                                                                  <?php echo e($Round->CourseNameEn); ?> GR <?php echo e($Round->GroupNo); ?>

                                                                </span>
                                                              </td>
                                                              <td> <?php echo e($Round->StartDate); ?> </td>
                                                              <td> <?php $i = 0; ?>
                                                                <?php $__currentLoopData = $TrainerRounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($Trainer->RoundId == $Round->RoundId): ?>
                                                                    <?php  $i++ ?>
                                                                    <?php if($i > 1): ?>
                                                                    , <?php echo e($Trainer->FullnameEn); ?>

                                                                    <?php else: ?>
                                                                    <?php echo e($Trainer->FullnameEn); ?>

                                                                    <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                                                </td>
                                                              <td> <?php echo e($Round->BranchNameEn); ?> </td>
                                                              <td> Lab <?php echo e($Round->LabNumber); ?> </td>
                                                             
                                                             
                                                              
                                                             
                                                            </tr>
                                                            <?php
                                                                $i++
                                                            ?>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                          
                                                            
                                                           
                                                          
                                                           
                                                          </tbody>
                                                        </table>  
                                            </div>
                                        </div>
                                       
                                        
                                    </div>
                                </div>
                    </div>

                </div>

            </div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>