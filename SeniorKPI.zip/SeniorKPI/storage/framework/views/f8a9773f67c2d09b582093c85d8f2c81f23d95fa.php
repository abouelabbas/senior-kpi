<?php $__env->startSection('content'); ?>
    
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html"><i class="material-icons">home</i> Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><a href="my-Courses.html">My Courses</a></li>
              <li class="breadcrumb-item active" aria-current="page">Students</li>
            </ol>
          </nav>
      <div class="row">

        <div class="col-md-12">

          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>Students List </h6>
            </div>
            <div class="ms-panel-body">
               
              <div class="table-responsive">
                <table class=" fixed-thead-width dattable table table-striped thead-dark  w-100">
                  <thead>
                    <th>Student Name </th>
                    <th> Attendence</th>
                    <th>  Time Respect </th>
                    <th>Lecture Respect</th>
                    <th>Interaction</th>
                    <th>Attiude</th>
                    <th>Focus</th>
                    <th>Understanding Speed</th>
                    <th>Total</th>
                  </thead>
                  <tbody>
                    <tr>
                        <td><a href="student-evalution-details.html">Mohmmad Gaml</a></td>
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.76"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                76%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.55"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;orange&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                55%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.40"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                40%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.77"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                77%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.70"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                70%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.50"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                50%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.60"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;yellow&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                60%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.88"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                88%
                            </div>
                          </div>
                            </td>
                           
                       
                      </tr>
                    <tr>
                        <td><a href="student-details.html">Mohmmad Gaml</a></td>
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.76"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                76%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.55"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;orange&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                55%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.40"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                40%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.77"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                77%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.70"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                70%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.50"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                50%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.60"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;yellow&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                60%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.88"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                88%
                            </div>
                          </div>
                            </td>
                           
                       
                      </tr>
                    <tr>
                        <td><a href="student-details.html">Mohmmad Gaml</a></td>
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.76"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                76%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.55"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;orange&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                55%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.40"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                40%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.77"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                77%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.70"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                70%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.50"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                50%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.60"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;yellow&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                60%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.88"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                88%
                            </div>
                          </div>
                            </td>
                           
                       
                      </tr>
                    <tr>
                        <td><a href="student-details.html">Mohmmad Gaml</a></td>
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.76"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                76%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.55"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;orange&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                55%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.40"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                40%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.77"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                77%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.70"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                70%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.50"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;red&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                50%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.60"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;yellow&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                60%
                            </div>
                          </div>
                            </td>
                           
                          <td>
                            <div
                            class="progress-circle"
                            data-value="0.88"
                            data-size="50"
                            data-thickness="3"
                            data-animation-start-value="1.0"
                            data-fill="{
                              &quot;color&quot;: &quot;green&quot;
                            }"
                            data-reverse="true">
                            <div class="percent">
                                88%
                            </div>
                          </div>
                            </td>
                           
                       
                      </tr>
                   
                  </tbody>
                </table>  
              </div>
            </div>
          </div>
        
        </div>

      </div>
    </div>

  </main>

   <!-- Task Modal -->
   <div class="modal fade" id="addStudent" tabindex="-1" role="dialog" aria-labelledby="addStudent">
      <div class="modal-dialog modal-dialog-centered modal " role="document">
        <div class="modal-content">
  
          <div class="modal-body">
  
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="ms-auth-container row no-gutters">
                <div class="col-12 p-3">
                    <form action="">
                      
                      <div class="form-group">
                          <label for="note">Student Name</label>
                          <div class="input-group">
                             <input type="text" class="form-control" placeholder="Student name">
                          </div>
                      </div>
                      <div class="form-group">
                          <label for="note">Hours</label>
                          <div class="input-group">
                             <input type="text" class="form-control" placeholder="Hours">
                          </div>
                      </div>
                      <div class="form-group">
                          <label for="note">Instructor</label>
                          <div class="input-group">
                             <input type="text" class="form-control" placeholder="Instructor">
                          </div>
                      </div>
                      <div class="form-group">
                          <label for="note">Branch</label>
                          <div class="input-group">
                             <input type="text" class="form-control" placeholder="Branch">
                          </div>
                      </div>
                      <div class="input-group d-flex justify-content-end text-center">
                        <input type="button" value="Cancel" class="btn btn-dark mx-2" data-dismiss="modal" aria-label="Close">                       
                        <input type="submit" value="Add" class="btn btn-success ">                       
                    </div>
                    </form>
                </div>
              </div>
            </div>
  
          </div>
        </div>
      </div>
  
  <!-- Task Modal -->
  <div class="modal fade" id="DoneTopics" tabindex="-1" role="dialog" aria-labelledby="DoneTopics">
      <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
  
          <div class="modal-body">
  
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="ms-auth-container row no-gutters">
                <div class="col-12 p-3">
                  <form action="">
                   <div class="row">
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" checked="">
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> HTML </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" checked="">
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> CSS </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" checked="">
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> CSS3 </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> JavaScript </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                     <div class="col-md-6 my-2">
                     
                        <label class="ms-checkbox-wrap ms-checkbox-success">
                          <input type="checkbox" value="" >
                          <i class="ms-checkbox-check"></i>
                        </label>
                        <span> Jquery </span>
                     </div>
                    
                   </div>
                   <div class="input-group d-flex justify-content-end text-center">
                    <input type="button" value="Cancel" class="btn btn-dark mx-2" data-dismiss="modal" aria-label="Close">                       
                    <input type="submit" value="Add" class="btn btn-success ">                       
                </div>
                  </form>
                </div>
              </div>
            </div>
  
          </div>
        </div>
      </div>




      <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.adminkpi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>