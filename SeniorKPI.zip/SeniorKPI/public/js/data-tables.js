(function($) {
  'use strict';


  let StudentTable = $('.dattable').DataTable({
    "lengthMenu": [5, 10, 15, 20, 25, 30, 40, "All"]
  })


})(jQuery);
